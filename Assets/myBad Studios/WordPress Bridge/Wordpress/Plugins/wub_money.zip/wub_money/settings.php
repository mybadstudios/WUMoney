<?php
include_once(dirname(__FILE__) . "/../wub_login/functions.php");
include_once("Settings/wub_money.php");

add_filter("wub_section_heading", "wub_add_money_menu",19,2);
add_filter("wub_section_content", "wub_show_money_section", 21, 2);

function wub_add_money_menu($value)
{
	$menu_button = new WubMenuItem('Money');
	return $value . $menu_button->GenerateMenuButton();
}

function wub_show_money_section($content, $test)
{
	return (MENUTAB == MONEY_CONSTANT) ? show_wub_money_content() : $content;
}

add_action( 'admin_enqueue_scripts', 'enqueue_wumoney_scripts' );

function enqueue_wumoney_scripts()
{
	wp_register_script( 'wub_tapjoy_ajax_functions', plugins_url( 'js/tapjoy_ajax.js', __FILE__ ) );
	wp_enqueue_script( 'wub_tapjoy_ajax_functions' );
}
