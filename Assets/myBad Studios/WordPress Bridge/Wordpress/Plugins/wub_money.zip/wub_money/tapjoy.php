<?php
define('WP_USE_THEMES', false );

require_once( dirname(__FILE__) . '/../../../wp-load.php' );

@header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
@header( 'X-Robots-Tag: noindex' );

require_once(dirname(__FILE__) . "/../wub_login/functions.php");
require_once(dirname(__FILE__) . "/classes/WubMoney.class.php");

//set to false when going live
define("DEV_MODE", true);

$tapjoy = WubMoney::tapjoy_construct();
if ($tapjoy->AuthenticateCall())
{
	$status = $tapjoy->_reportSuccess( $tapjoy->AcceptPoints( ) ? 200 : 403);

	if (DEV_MODE && $status == 403)
	$tapjoy->__devmode_failure_notification();
} else
{
	$tapjoy->_reportSuccess(403);
	if (DEV_MODE)
	$tapjoy->__devmode_failure_notification();
}
die();

