<?php
class WubMoney {
	var
		$snuid,
		$uid,
		$currency,
		$qty,
		$mac,
		$gid,
		$transaction_id,
		$log_table,
		$verifier;

	static public function tapjoy_construct()
	{
		$instance = new static();

		$snuid = Posted('snuid');
		$fields = explode('_', $snuid);

		$gid = trim($fields[0]);
		$uid = trim($fields[1]);
		$qty = Postedi('currency');
		$mac = Posted('mac_address');
		$id = Posted('id');
		$verifier = Posted('verifier');

		$instance->_init($snuid, $gid, $uid, $qty, $mac, $id, $verifier );
		return $instance;
	}

	static public function construct($uid, $gid, $qty, $currency='points')
	{
		$instance = new static();

		$instance->_init('', $gid, $uid, $qty, '', '', '', $currency);
		return $instance;
	}

	function _init($snuid, $gid, $uid, $amt, $mac, $id = '', $verifier = '', $currency = 'points')
	{
		if (trim($currency) == '') $currency = 'points';
		$this->snuid = $snuid;
		$this->gid = $gid;
		$this->uid = $uid;
		$this->qty = $amt;
		$this->mac = $mac;
		$this->transaction_id = $id;
		$this->verifier = $verifier;
		$this->currency = $currency;
		$this->log_table = "wub_money_awards_log";
	}

	function __currencySecret($platform)
	{
		return get_post_meta($this->gid,'tapjoy_currency_secret_'.$platform, true);
	}

	function __authenticated()
	{
		$key_name = "{$this->transaction_id}:{$this->snuid}:{$this->qty}:";
		return(md5( $key_name . $this->__currencySecret('ios') ) == $this->verifier ||
		       md5( $key_name . $this->__currencySecret('android') ) == $this->verifier );
	}

	public function __devmode_failure_notification()
	{
		$send_to  = get_option('admin_email');
		$headers = 'From: noreply@example.com' . "\r\n" . 'Reply-To: noreply@example.com' . "\r\n" . 'X-Mailer: PHP/' . phpversion();
		$message = "Authentication failed for transaction {$this->transaction_id}. USER: {$this->uid}, GAME: {$this->gid}, AMOUNT: {$this->qty}";
		mail($send_to, 'Tapjoy authentication failure details', $message, $headers);
	}

	//used by TapJoy's server callback
	public function AuthenticateCall()
	{
		if(isset($this->transaction_id) || isset($this->verifier))
		{
			if ( $this->__authenticated() )
				return true;

			//if the function didn't just return true, send an email stating that an error occurred
			$this->__devmode_failure_notification();
			return false;
		}
		return true;
	}

	//send this back to TapJoy servers
	public function _reportSuccess($code)
	{
		if (!function_exists('http_response_code'))
			header('X-PHP-Response-Code: '.$code, true, $code);
		else
			http_response_code($code);
		return $code;
	}

	function __updateBalance($amt)
	{
		$meta_key =  "{$this->gid}_currency_{$this->currency}";
		$balance = get_user_meta($this->uid, $meta_key, true);
		$balance = empty($balance) ? 0 : intval($balance);
		$balance += $amt;
		return true === update_user_meta($this->uid, $meta_key, $balance);
	}

	public function FetchBalance() {
		$meta_key =  "{$this->gid}_currency_{$this->currency}";
		$balance = get_user_meta($this->uid, $meta_key, true);
		$balance = empty(trim($balance)) ? 0 : intval($balance);
		return $balance;
	}

	public function SpendPoints()
	{
		if ($this->qty < 0)
		{
			$this->ReturnError("Cannot spend negative values. Use GivePoints instead",1);
			return false;
		}

		$balance = $this->FetchBalance();
		if (0 == $balance)
		{
			$this->ReturnError("No credit",2);
			return false;
		}

		if ($balance < $this->qty)
		{
			$this->ReturnError("Insufficient balance",3);
			return false;
		}
		$this->__updateBalance($this->qty * -1);
		return true;
	}

	public function GivePoints()
	{
		if ($this->qty < 0)
		{
			$this->ReturnError("Cannot give negative values. Use SpendPoints instead",4);
			return false;
		}

		$this->__updateBalance($this->qty);
		return true;
	}

	//This function is called by the TapJoy server only. Do not modify
	public function AcceptPoints()
	{
		$result = $this->GivePoints();
		if ($result)
			$this->LogTapjoyPoints();
		return $result;
	}

	//generic error response template used by the WUB TapJoy kit
	//print whatever the error was, along with a code to let developers show custom error messages
	//also send along the current points balance for good measure
	function ReturnError($msg, $code)
	{
		$meta = (isset($_REQUEST['meta'])) ? trim($_REQUEST['meta']) : '';
		$response = PrintError($msg, $code);
		$response .= SendField('value', $this->FetchBalance());
		$response .= SendField('currency', $this->currency);

		if ($meta != '')
			$response .= SendField('meta', $meta);
		$response .= $this->TestForAwardedPoints();

		SendToUnity($response);
	}

	//Keep a log of when TapJoy points were awarded and to who in case anyone queries a possible lost transaction
	//If TapJoy awarded any points via the server, that points will be added to the player's balance but
	//there is no system in place to actually TELL the player that he got points from TapJoy
	//For that reason I create an entry in usermeta that stores how many points the player received, tallying the total
	function LogTapjoyPoints()
	{
		global $wpdb;
		$wpdb->insert(
			$this->log_table,
			array(
				'gid' => $this->gid,
				'uid' => $this->uid,
				'amount' =>$this->qty,
				'transaction' => $this->transaction_id,
				'source' => 'Tapjoy'),
			array('%d','%d','%d','%s','%s'));

		$meta_key =  "{$this->gid}_tapjoy_points_awarded";
		$balance = get_user_meta($this->uid, $meta_key, true);
		$balance = empty($balance) ? 0 : intval($balance);
		$balance += $this->qty;
		update_user_meta($this->uid, $meta_key, $balance);
	}

	//Keep a log of all virtual currency awarded from cash purchases
	public function LogPurchase($currency, $source="WooPurchase")
	{
		global $wpdb;
		$wpdb->insert(
			$this->log_table,
			array(
				'gid' => $this->gid,
				'uid' => $this->uid,
				'amount' =>$this->qty,
				'transaction' => $currency.'-'.time().'-'.(rand()),
				'source' => $source),
			array('%d','%d','%d','%s','%s'));

		//"points" is a special case since that is the currency awarded by Tapjoy
		//if you, for some reason, decided to sell "points" from your website
		//WUMoney shows an in game notification of Tapjoy points that was awarded
		//so set up that notification to get triggered
		if ($this->currency == 'points' && $this->gid > 0) {
			$meta_key = "{$this->gid}_tapjoy_points_awarded";
			$balance = get_user_meta($this->uid, $meta_key, TRUE);
			$balance = empty($balance) ? 0 : intval($balance);
			$balance += $this->qty;
			update_user_meta($this->uid, $meta_key, $balance);
		}
	}

	public function GetTransactionHistory($uid, $gid=-1)
	{
		global $wpdb;
		$mod1 = $gid < 0 ? 'gid,' : '';
		$mod2 = $gid < 0 ? '' : " AND gid='$gid'";
		return $wpdb->get_results("SELECT $mod1 awarded, amount, transaction, source FROM $this->log_table WHERE uid='$uid'$mod2 ORDER BY awarded");
	}

	//Every time the system is contacted from within Unity, check if the player had received points from TapJoy
	//If the player has any points, send that information along to Unity and then clear the list
	//Developers can decide if they want to display some kind of "You got 10 points" notification or not
	//It is entirely optional since the balance already contains the points anyway. Purely for informational purposes
	function TestForAwardedPoints()
	{
		$meta_key =  "{$this->gid}_tapjoy_points_awarded";
		$awarded  = get_user_meta($this->uid, $meta_key, true);
		if (empty($awarded) || intval($awarded) == 0)
			return '';

		$total = $this->FetchBalance();
		update_user_meta($this->uid, $meta_key, '0');
		if (empty(trim($total)))
			$total = 0;
		return SendNode('TapjoyAwarded', "value={$awarded}; total={$total}");
	}
}