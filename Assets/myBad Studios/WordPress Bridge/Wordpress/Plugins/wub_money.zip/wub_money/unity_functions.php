<?php

//load this first as this makes sure the WP themes are not processed
include_once(dirname(__FILE__) . "/../wub_login/settings.php");

function __returnCurrentBalance($amount, $awarded)
{
	$meta = trim(Posted('meta'));
	$response  = SendField('value', $amount);
	$response .= SendField('currency', Posted('currency'));

	if ($meta != '')
		$response .= SendField('meta', $meta);

	$response .= $awarded;
	SendToUnity($response);
}

function moneyGetPoints() {
	global $current_user;

	$points = WubMoney::construct($current_user->ID, Postedi("gid"), 0, Posted("currency"));
	__returnCurrentBalance($points->FetchBalance(), $points->TestForAwardedPoints() );
}

function moneySpendPoints() {
	global $current_user;

	$points = WubMoney::construct($current_user->ID, Postedi("gid"), Postedi("amt"), Posted("currency"));
	if ($points->SpendPoints())
		__returnCurrentBalance($points->FetchBalance(), $points->TestForAwardedPoints() );
}

function moneyGivePoints() {
	global $current_user;

	$points = WubMoney::construct($current_user->ID, Postedi("gid"), Postedi("amt"), Posted("currency"));
	if ($points->GivePoints() )
		__returnCurrentBalance($points->FetchBalance(), $points->TestForAwardedPoints() );
}


